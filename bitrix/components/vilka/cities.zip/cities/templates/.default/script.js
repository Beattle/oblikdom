$(function(){
    $('.regions').on('click', function(){
        $.fancybox.open($('.region_list'),{
            minwidth:350,
            minHeight:100,
            maxWidth:400,
            maxHeight:500,
            autoSize: true
        });
        return false;
    })
});