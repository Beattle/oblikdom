<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();


$arComponentParameters = array(
	"PARAMETERS" => array(
		"USE_JQ" => Array(
			"NAME" => GetMessage("VSEO_JQ"),
			"TYPE" => "CHECKBOX",
			"DEFAULT" => "N",
			"PARENT" => "BASE",
		),
        "USE_FB" => Array(
            "NAME" => GetMessage("VSEO_FB"),
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "N",
            "PARENT" => "BASE",
        ),
	)
);